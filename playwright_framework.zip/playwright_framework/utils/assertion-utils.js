const { expect } = require('@playwright/test');
//const { loadBannerConfig } = require('../config/config-loader');
//const banner = loadBannerConfig(); // Load banner configuration
const { webUtils } = require('../utils/web-utils');

/**
 * Custom assertion utility class for Playwright tests
 * This provides a unified interface for common assertions
 */
class AssertionUtils {
  constructor(page) {
    this.page = page;
    this.webUtils = webUtils(this.page);
  }


  // =================================
  // TEXT ASSERTIONS
  // =================================


  /**
   * Assert success message is displayed
   */
  async expectSuccessMessage(message) {
    const successSelectors = [
      '.success-message',
      '.alert-success',
      '.notification-success',
      '[role="alert"].success',
      '.toast-success'
    ];
    let messageFound = false;
    for (const selector of successSelectors) {
      const exists = await this.page.locator(selector).count() > 0;
      if (exists) {
        await this.expectToBeVisible(selector);
        if (message) {
          await this.expectTextToBeVisible(selector, message);
        }
        messageFound = true;
        break;
      }
    }
    expect(messageFound).toBeTruthy();
  }


  /**
   * Assert error message is displayed
   */
  async expectErrorMessage(message) {
    const errorSelectors = [
      '.error-message',
      '.alert-error',
      '.alert-danger',
      '.notification-error',
      '[role="alert"].error',
      '.toast-error'
    ];
    let messageFound = false;
    for (const selector of errorSelectors) {
      const exists = await this.page.locator(selector).count() > 0;
      if (exists) {
        await this.expectToBeVisible(selector);
        if (message) {
          await this.expectTextToBeVisible(selector, message);
        }
        messageFound = true;
        break;
      }
    }
    expect(messageFound).toBeTruthy();
  }


  /**
   * Assert page has no accessibility violations
   * Requires axe-playwright to be installed
   */
  async expectNoAccessibilityViolations(options) {
    try {
      const { injectAxe, checkA11y } = require('axe-playwright');
      // Inject axe-core into the page
      await injectAxe(this.page);
      // Run accessibility tests
      await checkA11y(this.page, null, {
        axeOptions: {
          runOnly: {
            type: 'tag',
            values: ['wcag2a', 'wcag2aa']
          },
          includedImpacts: options?.includedImpacts || ['critical', 'serious']
        },
        detailedReport: true
      });
    } catch (error) {
      if (error.message.includes("Cannot find module 'axe-playwright'")) {
        throw new Error('axe-playwright is not installed. Run: npm install -D axe-core axe-playwright');
      } else {
        throw error;
      }
    }
  }


  /**
   * Assert element contains text
   */
  async expectTextToBeVisible(selector, text, options) {
    const element = typeof selector === 'string'
      ? this.page.locator(selector)
      : selector;
    await expect(element).toContainText(text, { timeout: options?.timeout });
    console.log(`verified the ${element} to contain the text ${text}`);
  }


  /**
   * Assert element has exact text
   */
  async expectExactText(selector, text, options) {
    const element = typeof selector === 'string'
      ? this.page.locator(selector)
      : selector;
    await expect(element).toHaveText(text, { timeout: options?.timeout });
    console.log(`verified the ${element} to have the exact text ${text}`);
  }

  /**
  * Assert text content of multiple elements
  */
  async checkElementsText(elements, texts, options) {
    // Iterate over both elements and texts
    for (let i = 0; i < elements.length; i++) {
      const element = elements[i];
      const expectedText = texts[i];
      await this.expectExactText(element, expectedText, options);
      console.log(`verified the ${element} to have the text ${expectedText}`);
    }
  }

  /**
   * Assert that any of the elements has the specified text
   */
  async expectAnyElementToHaveText(selector, text, options) {
    const element = typeof selector === 'string'
      ? this.page.locator(selector)
      : selector;
    let foundText = false;
    const count = await element.count();
    for (let i = 0; i < count; i++) {
      const elementText = await element.nth(i).textContent();
      if (typeof text === 'string') {
        if (elementText?.includes(text)) {
          foundText = true;
          break;
        }
      } else if (text.test(elementText || '')) {
        foundText = true;
        break;
      }
    }
    expect(foundText).toBeTruthy();
  }


  /**
   * Assert that none of the elements have the specified text
   */
  async expectNoElementToHaveText(selector, text, options) {
    const element = typeof selector === 'string'
      ? this.page.locator(selector)
      : selector;
    let foundText = false;
    const count = await element.count();
    for (let i = 0; i < count; i++) {
      const elementText = await element.nth(i).textContent();
      if (typeof text === 'string') {
        if (elementText?.includes(text)) {
          foundText = true;
          break;
        }
      } else if (text.test(elementText || '')) {
        foundText = true;
        break;
      }
    }

    if (foundText) {
      throw new Error(`❌ One or more elements contain the text: "${text}"`);
    } else {
      console.log(`✅ None of the elements contain the text: "${text}"`);
    }


    expect(foundText).toBeFalsy();
  }


  /**
 * Assert element does NOT contain text
 */
  async expectTextNotToBeVisible(selector, text, options) {
    const element = typeof selector === 'string'
      ? this.page.locator(selector)
      : selector;
    await expect(element).not.toContainText(text, { timeout: options?.timeout });
    console.log(`verified the ${element} does NOT contain the text ${text}`);
  }


  /**
   * Assert page contains text
   */
  async expectPageToContainText(text, options) {
    const bodyText = this.page.locator('body');
    await expect(bodyText).toContainText(text, { timeout: options?.timeout });
  }

  // =================================
  // VISIBILITY ASSERTIONS
  // =================================


  /**
   * Assert element is visible
   */
  async expectToBeVisible(selector, options) {
    const element = typeof selector === 'string'
      ? this.page.locator(selector)
      : selector;
    await expect(element).toBeVisible({ timeout: options?.timeout || 15000 });
    console.log(`Verified that the ${element} is visible`);
  }


  /**
   * @author: Abhishek Zende
 * Assert visibility of multiple elements (array of locators or selectors)
 */
  async expectAllToBeVisible(elements, options) {
    for (const selector of elements) {
      const element = typeof selector === 'string' ? this.page.locator(selector) : selector;
      await expect(element).toBeVisible({ timeout: options?.timeout || 60000 });
      console.log(`Verified that the ${element} is visible`);
    }
  }


  /**
   * Assert visibility of multiple elements
   */
  async checkElementsVisibility(elements, options) {
    // Check if the locator is valid
    if (!elements) {
      throw new TypeError('Expected a valid locator, but received: ' + elements);
    }
    // Get the count of elements matching the locator
    const count = await elements.count();

    // Log the number of elements for debugging
    console.log(`Checking visibility of elements for ${count} elements.`);

    // Iterate over each element and check visibility
    for (let i = 0; i < count; i++) {
      const element = elements.nth(i); // Get the nth element
      await this.expectToBeVisible(element, options); // Use expectToBeVisible for each element
    }
  }

  /**
 * Assert invisibility of multiple elements
 */
  async checkElementsInvisibility(elements, options) {
    // Check if the locator is valid
    if (!elements) {
      throw new TypeError('Expected a valid locator, but received: ' + elements);
    }
    // Get the count of elements matching the locator
    const count = await elements.count();

    // Log the number of elements for debugging
    console.log(`Checking invisibility of elements for ${count} elements.`);

    // Iterate over each element and check invisibility
    for (let i = 0; i < count; i++) {
      const element = elements.nth(i); // Get the nth element
      await this.expectToBeHidden(element, options); // Use expectToBeHidden for each element
    }
  }

  /**
   * Assert element is hidden
   */
  async expectToBeHidden(selector, options) {
    const element = typeof selector === 'string'
      ? this.page.locator(selector)
      : selector;
    await expect(element).toBeHidden({ timeout: options?.timeout });
  }


  /**
   * Assert element exists in DOM (regardless of visibility)
   */
  async expectToExist(selector, options) {
    const element = typeof selector === 'string'
      ? this.page.locator(selector)
      : selector;
    await expect(element).toHaveCount(1, { timeout: options?.timeout });
  }


  /**
   * Assert element does not exist in DOM
   */
  async expectNotToExist(selector, options) {
    const element = typeof selector === 'string'
      ? this.page.locator(selector)
      : selector;
    //await expect(element).toHaveCount(0, { timeout: options?.timeout });
    const selectorDescription = typeof selector === 'string' ? selector : element.toString();;
    console.log(`🔍 Checking that element does NOT exist: ${selectorDescription}`);

    try {
      await expect(element).toHaveCount(0, { timeout: options?.timeout });
      console.log(`✅ Element not found as expected: ${selectorDescription}`);
    } catch (error) {
      console.error(`❌ Element was found but should not exist: ${selectorDescription}`);
      throw error; // rethrow to fail the test
    }

  }


  // =================================
  // COUNT ASSERTIONS
  // =================================


  /**
   * Assert element count equals expectation
   */
  async expectCount(selector, count, options) {
    const element = typeof selector === 'string'
      ? this.page.locator(selector)
      : selector;
    await expect(element).toHaveCount(count, { timeout: options?.timeout });
  }


  /**
   * Assert element count is greater than expectation
   */
  async expectCountGreaterThan(selector, count) {
    const element = typeof selector === 'string'
      ? this.page.locator(selector)
      : selector;
    const actualCount = await element.count();
    expect(actualCount).toBeGreaterThan(count);
  }


  /**
   * Assert element count is less than expectation
   */
  async expectCountLessThan(selector, count) {
    const element = typeof selector === 'string'
      ? this.page.locator(selector)
      : selector;
    const actualCount = await element.count();
    expect(actualCount).toBeLessThan(count);
  }


  // =================================
  // ATTRIBUTE ASSERTIONS
  // =================================


  /**
   * Assert element has attribute with specific value
   */
  async expectAttributeValue(selector, attribute, value, options) {
    const element = typeof selector === 'string'
      ? this.page.locator(selector)
      : selector;
    await expect(element).toHaveAttribute(attribute, value, { timeout: options?.timeout });
  }

  /**
  * Assert multiple elements has same attribute with specific value
  */
  async expectElementsAttributeValue(elements, attribute, value, options) {
    for (const element of elements) {
      await this.expectAttributeValue(element, attribute, value, options)
    }
  }

  /**
   * Assert element has attribute (regardless of value)
   */
  async expectToHaveAttribute(selector, attribute, options) {
    const element = typeof selector === 'string'
      ? this.page.locator(selector)
      : selector;

    const hasAttribute = await element.evaluate((el, attr) => {
      return el.hasAttribute(attr);
    }, attribute);
    expect(hasAttribute).toBeTruthy();
  }

  /**
  * Assert multiple elements have specified attribute (regardless of value)
  */
  async expectElementsToHaveAttribute(elements, attribute, options) {
    // Check if the locator is valid
    if (!elements) {
      throw new TypeError('Expected a valid locator, but received: ' + elements);
    }

    // Get the count of elements matching the locator
    const count = await elements.count();

    // Log the number of elements for debugging
    console.log(`Checking attribute of elements.`);
    // Iterate over each element and check visibility
    for (let i = 0; i < count; i++) {
      const element = elements.nth(i); // Get the nth element
      await this.expectToHaveAttribute(element, attribute, options)
    }

  }

  /**
   * Assert element does not have specific attribute
   */
  async expectNotToHaveAttribute(selector, attribute) {
    const element = typeof selector === 'string'
      ? this.page.locator(selector)
      : selector;

    const hasAttribute = await element.evaluate((el, attr) => {
      return el.hasAttribute(attr);
    }, attribute);

    expect(hasAttribute).toBeFalsy();
  }


  /**
   * Assert element has CSS class
   */
  async expectToHaveClass(selector, className, options) {
    const element = typeof selector === 'string'
      ? this.page.locator(selector)
      : selector;
    // Wait for the element to be visible before checking the class
    await element.waitFor({ state: 'visible' });

    // Check if className is a RegExp or a string
    if (className instanceof RegExp) {
      const classList = await element.getAttribute('class');
      expect(classList).toMatch(className);
    } else {
      //await expect(element).toHaveClass(className, { timeout: options?.timeout });  //This line of code was checking for exact match of the class name passed as a string.
      // FIX: Check if className is present in the class list
      const classList = await element.getAttribute('class');
      expect(classList.split(/\s+/)).toContain(className);
    }
  }


  /**
   * Assert element does not have CSS class
   */
  async expectNotToHaveClass(selector, className, options) {
    const element = typeof selector === 'string'
      ? this.page.locator(selector)
      : selector;
    if (typeof className === 'string') {
      const classes = await element.getAttribute('class');
      const classArray = classes ? classes.split(' ') : [];
      expect(classArray).not.toContain(className);
    } else {
      const classes = await element.getAttribute('class');
      expect(classes).not.toMatch(className);
    }
  }


  // =================================
  // URL AND NAVIGATION ASSERTIONS
  // =================================


  /**
   * Assert current URL equals or matches expectation
   */
  async expectURL(url, options) {
    await this.webUtils.waitForLoader(this.page);
    const currentUrl = this.page.url();
    console.log("Current URL: " + currentUrl);
    console.log("Expected URL: " + url);
    await expect(this.page).toHaveURL(url, { timeout: options?.timeout });
  }


  /**
   * Assert current URL contains specific string
   */
  async expectURLToContain(urlPart, options) {
    await this.webUtils.waitForLoader(this.page);
    const currentUrl = decodeURIComponent(this.page.url());
    console.log("Current URL: " + currentUrl);
    console.log("Expected URL: " + urlPart);
    expect(currentUrl).toContain(urlPart, { timeout: options?.timeout });
  }


  /**
   * Assert page title equals or matches expectation
   */
  async expectTitle(title, options) {
    await expect(this.page).toHaveTitle(title, { timeout: options?.timeout });
  }


  /**
   * Assert page title contains specific string
   */
  async expectTitleToContain(titlePart, options) {
    await expect(this.page).toHaveTitle(new RegExp(titlePart), { timeout: options?.timeout });
  }


  // =================================
  // ELEMENT STATE ASSERTIONS
  // =================================


  /**
   * Assert element is enabled
   */
  async expectElementEnabled(selector, options) {
    const element = typeof selector === 'string'
      ? this.page.locator(selector)
      : selector;
    await expect(element).toBeEnabled({ timeout: options?.timeout });
  }


  /**
   * Assert element is disabled
   */
  async expectElementDisabled(selector, options) {
    const element = typeof selector === 'string'
      ? this.page.locator(selector)
      : selector;
    await expect(element).toBeDisabled({ timeout: options?.timeout });
  }


  /**
   * Assert checkbox or radio is checked
   */
  async expectToBeChecked(selector, options) {
    const element = typeof selector === 'string'
      ? this.page.locator(selector)
      : selector;
    await expect(element).toBeChecked({ timeout: options?.timeout });
  }


  /**
   * Assert checkbox or radio is not checked
   */
  async expectNotToBeChecked(selector, options) {
    const element = typeof selector === 'string'
      ? this.page.locator(selector)
      : selector;
    await expect(element).not.toBeChecked({ timeout: options?.timeout });
  }


  /**
   * Assert element is focused
   */
  async expectToBeFocused(selector, options) {
    const element = typeof selector === 'string'
      ? this.page.locator(selector)
      : selector;
    await expect(element).toBeFocused({ timeout: options?.timeout });
  }


  /**
   * Assert element is not focused
   */
  async expectNotToBeFocused(selector) {
    const element = typeof selector === 'string'
      ? this.page.locator(selector)
      : selector;
    await expect(element).not.toBeFocused();
  }


  /**
   * Assert element has specific value (for input fields)
   */
  async expectToHaveValue(selector, value, options) {
    const element = typeof selector === 'string'
      ? this.page.locator(selector)
      : selector;
    await expect(element).toHaveValue(value, { timeout: options?.timeout });
    console.log(`verified ${element} to have value ${value}`);
  }

  /**
 * Assert Multiple elements to have specific value (for input fields)
 */
  async expectElementsToHaveValue(elements, value, options) {
    // Check if the locator is valid
    if (!elements) {
      throw new TypeError('Expected a valid locator, but received: ' + elements);
    }

    // Get the count of elements matching the locator
    const count = await elements.count();
    console.log(`Elements count is ${count}`);

    // Iterate over each element and check visibility
    for (let i = 0; i < count; i++) {
      const element = elements.nth(i); // Get the nth element
      await this.expectToHaveValue(element, String(value), options);
    }

  }


  /**
 * Assert Multiple elements to have specific value (for input fields)
 */
  async expectElementsToHaveValue(elements, value, options) {
    // Check if the locator is valid
    if (!elements) {
      throw new TypeError('Expected a valid locator, but received: ' + elements);
    }

    // Get the count of elements matching the locator
    const count = await elements.count();
    console.log(`Elements count is ${count}`);

    // Log the number of elements for debugging
    console.log(`Checking product quantity to have value ${value} for the added products.`);

    // Iterate over each element and check visibility
    for (let i = 0; i < count; i++) {
      const element = elements.nth(i); // Get the nth element
      await this.expectToHaveValue(element, String(value), options);
    }

  }

  // =================================
  // VISUAL AND PROPERTY ASSERTIONS
  // =================================


  /**
   * Assert element matches snapshot
   */
  async expectToMatchSnapshot(selector, snapshotName) {
    const element = typeof selector === 'string'
      ? this.page.locator(selector)
      : selector;
    expect(await element.screenshot()).toMatchSnapshot(snapshotName);
  }


  /**
   * Assert element has specific CSS property value
   */
  async expectCSSPropertyValue(selector, property, value) {
    const element = typeof selector === 'string'
      ? this.page.locator(selector)
      : selector;


    const propertyValue = await element.evaluate((el, prop) => {
      return window.getComputedStyle(el).getPropertyValue(prop);
    }, property);


    if (typeof value === 'string') {
      expect(propertyValue.trim()).toBe(value);
    } else {
      expect(propertyValue).toMatch(value);
    }
  }

  // ...existing code...

  /**
   * Assert multiple elements have specific CSS property value
   * @param {Locator|String} elements - Playwright locator or selector for multiple elements
   * @param {String} property - CSS property name
   * @param {String|RegExp} value - Expected value or pattern
   */
  async expectElementsCSSPropertyValue(elements, property, value) {
    // Accepts a locator or selector string
    const locator = typeof elements === 'string'
      ? this.page.locator(elements)
      : elements;

    const count = await locator.count();
    for (let i = 0; i < count; i++) {
      const element = locator.nth(i);
      const propertyValue = await element.evaluate((el, prop) => {
        return window.getComputedStyle(el).getPropertyValue(prop);
      }, property);

      if (typeof value === 'string') {
        expect(propertyValue.trim()).toBe(value);
      } else {
        expect(propertyValue).toMatch(value);
      }
    }
  }

  // ...existing code...
  /**
   * Assert element is in viewport
   */
  async expectToBeInViewport(selector) {
    const element = typeof selector === 'string'
      ? this.page.locator(selector)
      : selector;


    const isInViewport = await element.evaluate(el => {
      const rect = el.getBoundingClientRect();
      return (
        rect.top >= 0 &&
        rect.left >= 0 &&
        rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
        rect.right <= (window.innerWidth || document.documentElement.clientWidth)
      );
    });


    expect(isInViewport).toBeTruthy();
  }


  // =================================
  // TABLE AND LIST ASSERTIONS
  // =================================


  /**
   * Assert table contains specific text in specific cell
   */
  async expectTableCellToContain(tableSelector, row, column, text) {
    const cellSelector = `${tableSelector} tr:nth-child(${row}) td:nth-child(${column})`;
    await this.expectTextToBeVisible(cellSelector, text);
  }


  /**
   * Assert list contains item with specific text
   */
  async expectListToContainItem(listSelector, itemText) {
    const items = this.page.locator(`${listSelector} > li`);
    await this.expectAnyElementToHaveText(items, itemText);
  }


  /**
   * Assert dropdown has specific options
   */
  async expectDropdownToHaveOptions(selector, options) {
    const element = typeof selector === 'string'
      ? this.page.locator(selector)
      : selector;


    const optionElements = element.locator('option');
    const optionTexts = await optionElements.allTextContents();


    for (const option of options) {
      expect(optionTexts).toContain(option);
    }
  }


  // =================================
  // NETWORK AND RESPONSE ASSERTIONS
  // =================================


  /**
   * Assert response status code
   */
  async expectResponseStatus(urlOrPredicate, status) {
    const response = await this.page.waitForResponse(urlOrPredicate);
    expect(response.status()).toBe(status);
  }


  /**
   * Assert response body contains text or matches pattern
   */
  async expectResponseBody(urlOrPredicate, bodyTextOrPattern) {
    const response = await this.page.waitForResponse(urlOrPredicate);
    const body = await response.text();


    if (typeof bodyTextOrPattern === 'string') {
      expect(body).toContain(bodyTextOrPattern);
    } else {
      expect(body).toMatch(bodyTextOrPattern);
    }
  }


  /**
   * Assert response header value
   */
  async expectResponseHeader(urlOrPredicate, header, value) {
    const response = await this.page.waitForResponse(urlOrPredicate);
    const headers = response.headers();


    if (typeof value === 'string') {
      expect(headers[header.toLowerCase()]).toBe(value);
    } else {
      expect(headers[header.toLowerCase()]).toMatch(value);
    }
  }


  // =================================
  // CUSTOM AND COMPOSITE ASSERTIONS
  // =================================


  /**
   * Assert form validation error is displayed
   */
  async expectFormValidationError(fieldSelector, errorText) {
    // Check for common error patterns
    const errorSelectors = [
      `${fieldSelector} + .error`, // Adjacent sibling
      `${fieldSelector} ~ .error`, // General sibling
      `${fieldSelector}-error`, // ID based
      `[data-error-for="${fieldSelector.replace('#', '')}"]` // Data attribute
    ];


    let errorFound = false;


    for (const selector of errorSelectors) {
      const exists = await this.page.locator(selector).count() > 0;


      if (exists) {
        if (errorText) {
          await this.expectTextToBeVisible(selector, errorText);
        } else {
          await this.expectToBeVisible(selector);
        }
        errorFound = true;
        break;
      }
    }


    // Check for aria-invalid attribute
    if (!errorFound) {
      await this.expectAttributeValue(fieldSelector, 'aria-invalid', 'true');
    }
  }
  /**
   * Validates that all input elements matching the locator are visible,
   * contain a non-empty value, and are not editable (disabled or readonly).
   * 
   * @param {import('@playwright/test').Page} page - Playwright Page object
   * @param {string} locator - Locator string for the input elements
   * @throws Will throw an error if any input fails validation
   */
  async valMultipleInputFields(page, locator) {
    // Accept both string and Locator
    const inputs = typeof locator === 'string' ? page.locator(locator) : locator;
    const count = await inputs.count();

    for (let i = 0; i < count; i++) {
      const input = inputs.nth(i);

      // Wait for the input to be visible (throws if not visible in timeout)
      await input.waitFor({ state: 'visible', timeout: 5000 });

      // Check that the input has a non-empty value
      const value = await input.inputValue();
      if (value === undefined || value === null || value === '') {
        throw new Error(`Input at index ${i} with locator "${locator}" does not contain a value`);
      }

      // Check if input is disabled or readonly
      const isDisabled = await input.isDisabled();
      const isReadOnly = await input.evaluate(el => el.readOnly);
      if (!isDisabled && !isReadOnly) {
        throw new Error(`Input at index ${i} with locator "${locator}" is editable but should not be`);
      }
    }
  }

  /**
   * Verifies that the text of an element is truthy (not empty or whitespace).
   * @param {string | Locator} selector - The selector or locator of the element to check.
   * @throws Will throw an error if the text is not truthy.
   * 
  **/
  async expectTextToBeTruthy(selector) {
    const element = typeof selector === 'string'
      ? this.page.locator(selector)
      : selector;
    const text = await element.textContent();
    expect(text && text.trim()).toBeTruthy();
    console.log(`Verified that the text of ${element} is truthy: "${text && text.trim()}"`);
  }

  /**
   * @author: Manisha Padghane
   * Verifies that the price format of an element matches the configured regex.
   * @param {string | Locator} selector - The selector or locator of the element to check.
   * @throws Will throw an error if the price format does not match.
   */
  async expectPriceFormatToBeTruthy(selector) {
    const element = typeof selector === 'string'
      ? this.page.locator(selector)
      : selector;
    const text = await element.textContent();
    expect(text && text.trim()).toBeTruthy();

    const priceVerifier = new RegExp(banner.priceFormat.regex);

    // Assert the price format matches the regex
    const matches = priceVerifier.test(text);
    expect(matches).toBeTruthy();
    if (!matches) {
      throw new Error(`Price "${text}" does not match expected format: ${banner.priceFormat.regex}`);
    }

    console.log(`Verified that the price of ${element} is truthy: "${text && text.trim()}"`);
  }

  /**
   * @author: Manisha Padghane
   * Verifies that the price element is visible, contains valid price data, and returns the parsed price.
   * @param {string | Locator} priceElement - The selector or locator of the price element to check.
   * @returns {Promise<{value: number, currency: string, originalText: string}>} - The parsed price data.
   */
  async expectPriceToBeTruthy(priceElement) {
    // First verify the element is visible on page
    await this.expectToBeVisible(priceElement);

    // Get the parsed price data using helper function
    const priceData = await this.webUtils.getPriceFromElement(priceElement);

    // Series of assertions to validate price data
    expect(priceData).toBeTruthy();              // Object exists
    expect(priceData.value).toBeGreaterThan(0);  // Price is positive number
    expect(priceData.currency).toBeTruthy();     // Currency is present
    expect(priceData.originalText).toBeTruthy(); // Original text exists
    expect(priceData.originalText).toMatch(/[0-9]/); // Contains numbers

    // Return the price data for potential further use
    return priceData;
  }

  /**
   * @author: Manisha Padghane
   * Compares expected price data with actual price element data, allowing for tolerance and multiplier.
   * @param {Object} expectedPriceData - The expected price data object with value and currency
   * @param {string | Locator} actualPriceElement - The selector or locator of the actual price element
   * @param {Object} options - Options for tolerance and multiplier
   * @throws Will throw an error if the actual price does not match the expected price within tolerance.
   */
  async expectPriceToMatchData(expectedPriceData, actualPriceElement, options = {}) {
    // Parse the actual price from element
    const { tolerance = 0.01, multiplier = 1 } = options;
    const actualPriceData = await this.expectPriceToBeTruthy(actualPriceElement);

    // Assert both prices exist
    expect(expectedPriceData).toBeTruthy();
    expect(actualPriceData).toBeTruthy();
    console.log(`Expected Price Data: ${JSON.stringify(expectedPriceData.value * multiplier)} actual Price Data: ${JSON.stringify(actualPriceData.value)}`);
    // Compare numeric values with tolerance
    const difference = Math.abs(actualPriceData.value - expectedPriceData.value * multiplier);
    expect(difference).toBeLessThanOrEqual(tolerance);

    // Compare currency
    expect(actualPriceData.currency).toBe(expectedPriceData.currency);

    // Log comparison details
    console.log(`Price comparison passed:`);
  }
}



module.exports = { assertionUtils: (page) => new AssertionUtils(page) };