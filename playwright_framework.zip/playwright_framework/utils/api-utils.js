const { expect } = require('@playwright/test')

class APiUtils {

    constructor(apiContext, loginPayLoad) {
        this.apiContext = apiContext;
        this.loginPayLoad = loginPayLoad;
    }

    //Fetch the userId from the login API response
    async getUserid() {
        const loginresponse = await this.apiContext.post("https://rahulshettyacademy.com/api/ecom/auth/login", {
            data: this.loginPayLoad
        });

        const jsonBody = await loginresponse.json();

        const userid = jsonBody.userId;
        console.log(`User ID: ${userid}`);

        return userid;
    }

    async getToken() {
        const loginresponse = await this.apiContext.post("https://rahulshettyacademy.com/api/ecom/auth/login", {
            data: this.loginPayLoad
        });

        //Perform assertions to check the response status is 200 OK ... meaning check if the login was successful
        expect(loginresponse.status()).toBe(200);
        //loginresponse.ok() -> returns a boolean value "true" if the response status is within the range of 200-299
        expect(loginresponse.ok()).toBeTruthy();

        //Get response body as JSON
        const jsonBody = await loginresponse.json(); //Returns the JSON representation of response body.
        console.log(`Response Body as JSON representation: ${JSON.stringify(jsonBody)}`)

        console.log("==================================================================")
        //Extract token from the response
        const token = jsonBody.token;
        console.log(`Token: ${token}`);

        return token;
    }


    async createOrder(orderPayLoad) {

        let response = {}; //creating an empty javascript object which we will use to store orderid & token information

        response.token = await this.getToken(); //store the token in the response object created above

        const orderResponse = await this.apiContext.post("https://rahulshettyacademy.com/api/ecom/order/create-order", {
            data: orderPayLoad,
            headers: {
                'Authorization': response.token,
                'Content-Type': 'application/json'
            }
        })
        //Get response body as JSON
        const orderResponseJSON = await orderResponse.json();
        console.log(orderResponseJSON);
        //console.log(`Place Order Response is : ${JSON.stringify(orderResponseJSON)}`);
        const orderid = orderResponseJSON.orders[0];
        expect(orderResponseJSON.message.includes("Order Placed Successfully")).toBeTruthy();

        response.orderid = orderid; //store the orderid in the response object created above

        return response;  //returning the response object with orderid & token information from this method.
    }
    async getAPIResponse(page, expectedPath) {
        const request = await page.waitForRequest(request => {
            if (request.method() !== 'GET') return false;
            try {
                const url = new URL(request.url());
                return url.origin === tenantBaseUrl && url.pathname === expectedPath;
            } catch {
                return false;
            }
        });
        const response = await request.response();
        if (!response) {
            throw new Error('No response received for userSessionData API request');
        }
        if (response.status() !== 200) {
            throw new Error(`Expected status 200 but got ${response.status()}`);
        }

        return { request, response };
    }
 
}

module.exports = { APiUtils: (page) => new APiUtils(page) };