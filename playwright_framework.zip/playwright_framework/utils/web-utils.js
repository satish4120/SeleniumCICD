// src/utils/playwrightUtils.js
const { expect } = require('@playwright/test');
//const { loadBannerConfig } = require('../config/config-loader'); // Import the config loader
//const banner = loadBannerConfig(); // Load banner configuration
/**
 * Generic utility class for Playwright commands
 * This provides a unified interface for common Playwright operations
 */
class WebUtils {
  constructor(page) {
    this.page = page;
  }

  // =================================
  // NAVIGATION OPERATIONS
  // =================================

  /**
   * Navigate to a URL with network idle wait
   */
  async goto(url, options) {
    await this.page.goto(url, { waitUntil: 'networkidle', ...options });
  }

  /**
   * Navigate back in browser history
   */
  async goBack(options) {
    await this.page.goBack({ waitUntil: 'networkidle', ...options });
  }

  /**
   * Navigate forward in browser history
   */
  async goForward(options) {
    await this.page.goForward({ waitUntil: 'networkidle', ...options });
  }

  /**
   * Reload the current page
   */
  async reload(options) {
    await this.page.reload({ waitUntil: 'networkidle', ...options });
  }

  /**
 * Validate that the current page has redirected to the expected URL.
 * @author: Abhishek Zende
 * @param {string} expectedURL - The expected URL to check against the current page URL.
 */
  async verifyRedirectionToLink(expectedURL) {
    // Get the current URL of the page
    const currentUrl = this.page.url(); // This will still refer to the main page URL
    console.log("Current URL: " + currentUrl);
    console.log("Expected URL: " + expectedURL);
    // Assert that the current URL contains the expected URL
    expect(currentUrl).toContain(expectedURL);
  }

  // =================================
  // ELEMENT INTERACTION
  // =================================

  /**
   * Click on an element with built-in waits
   * selector: 'div.classname' or this.element
   * options: {timeout: 5000}
   */
  async clickElement(selector, options) {
    const element = typeof selector === 'string'
      ? this.page.locator(selector)
      : selector;
    try {
     // await this.waitForLoader(this.page);
      // Wait for element to be visible
      await element.waitFor({
        state: 'visible',
        timeout: options?.timeout || 5000
      });

      // Check if element is enabled using isEnabled()
      const isEnabled = await element.isEnabled();
      if (!isEnabled) {
        console.log('Waiting for element to be enabled...');
        await expect(element).toBeEnabled({
          timeout: options?.timeout || 5000
        });
      }
      // Perform click with navigation wait
      await Promise.all([
        element.click(),
        this.waitForNavigation({ waitUntil: 'load' }),
      ]);

      console.log(`Clicked on the element: ${element}`);
     // await this.waitForLoader(this.page);
    } catch (error) {
      console.error(`Failed to click element: ${error.message}`);
      throw new Error(`Element click failed: ${error.message}`);
    }
  }

  /**
     * Clicks the element if it exists (is visible or attached), otherwise does nothing.
     * @param {Locator} locator - Playwright Locator for the element.
     * @param {object} [options] - Options for clickElement (optional).
     */
  async clickIfExists(locator, options = { state: 'visible', timeout: 18000 }) {
    // Check if the element exists and is visible or attached
    try {
      if (await locator.isVisible({ timeout: 1000 })) {
        await this.webUtils.clickElement(locator, options);
        return true;
      }
    } catch (e) {
      console.warn('Element not visible:', e.message);
      try {
        if (await locator.isAttached()) {
          await this.webUtils.clickElement(locator, options);
          return true;
        }
      } catch (err) {
        console.warn('Element not attached:', err.message);
      }
    }
    return false;
  }

  /**
   * Double click on an element
   */
  async doubleClickElement(selector, options) {
    const element = typeof selector === 'string'
      ? this.page.locator(selector)
      : selector;
   // await this.waitForLoader(this.page)
    await element.waitFor({ state: 'visible', timeout: options?.timeout });
    await element.dblclick({ force: options?.force });
  }

  /**
   * Right click on an element
   */
  async rightClickElement(selector, options) {
    const element = typeof selector === 'string'
      ? this.page.locator(selector)
      : selector;
   // await this.waitForLoader(this.page)
    await element.waitFor({ state: 'visible', timeout: options?.timeout });
    await element.click({ button: 'right', force: options?.force });
  }

  /**
   * Hover over an element
   */
  async hoverElement(selector, options) {
    const element = typeof selector === 'string'
      ? this.page.locator(selector)
      : selector;
  //  await this.waitForLoader(this.page)
    await element.waitFor({ state: 'visible', timeout: options?.timeout });
    await element.hover({ force: options?.force });
  }

  /**
   * Fill a form field with text
   */
  async fillText(selector, text, options) {
    const element = typeof selector === 'string'
      ? this.page.locator(selector)
      : selector;
   // await this.waitForLoader(this.page)
    await element.waitFor({ state: 'visible', timeout: options?.timeout });
    await element.fill(text);
  }

  /**
   * Clear text from an input field
   */
  async clearText(selector, options) {
    const element = typeof selector === 'string'
      ? this.page.locator(selector)
      : selector;
   // await this.waitForLoader(this.page)
    await element.waitFor({ state: 'visible', timeout: options?.timeout });
    await element.clear();
  }

  /**
   * Type text with delay between keypresses
   */
  async pressSequentially(selector, text, options) {
    const element = typeof selector === 'string'
      ? this.page.locator(selector)
      : selector;
   // await this.waitForLoader(this.page)
    await element.waitFor({ state: 'visible', timeout: options?.timeout });
    await element.pressSequentially(text, { delay: options?.delay || 50 });
  }

  /**
   * Presses a key or a character on the element matching the specified locator
   */
  async press(selector, key, options) {
    try {
      const element = typeof selector === 'string'
        ? this.page.locator(selector)
        : selector;
    //  await this.waitForLoader(this.page)
      // Press the specified key with provided options
      await element.press(key, options)
    } catch (error) {
      console.error(`Failed to press key ${key} on locator ${selector}:`, error);
      throw error;
    }
  }

  /**
   * Select an option from a dropdown
   */
  async selectOption(selector, option, options) {
    const element = typeof selector === 'string'
      ? this.page.locator(selector)
      : selector;
   // await this.waitForLoader(this.page)
    await element.waitFor({ state: 'visible', timeout: options?.timeout });
    await element.selectOption(option);
  }

  /**
   * Check a checkbox or radio button
   */
  async checkElement(selector, options) {
    const element = typeof selector === 'string'
      ? this.page.locator(selector)
      : selector;
  //  await this.waitForLoader(this.page)
    await element.waitFor({ state: 'visible', timeout: options?.timeout });
    await element.check({ force: options?.force });
    console.log(`Checked the element: ${element}`);
  }

  /**
   * Uncheck a checkbox
   */
  async uncheckElement(selector, options) {
    const element = typeof selector === 'string'
      ? this.page.locator(selector)
      : selector;
   // await this.waitForLoader(this.page)
    await element.waitFor({ state: 'visible', timeout: options?.timeout });
    await element.uncheck({ force: options?.force });
    console.log(`UnChecked the element: ${element}`);
  }

  /**
   * Upload a file to an input field
   */
  async uploadFile(selector, filePath, options) {
    const element = typeof selector === 'string'
      ? this.page.locator(selector)
      : selector;
   // await this.waitForLoader(this.page)
    await element.waitFor({ state: 'visible', timeout: options?.timeout });
    await element.setInputFiles(filePath);
  }

  /**
   * Drag and drop an element
   */
  async dragAndDrop(source, target, options) {
    const sourceElement = typeof source === 'string'
      ? this.page.locator(source)
      : source;
    const targetElement = typeof target === 'string'
      ? this.page.locator(target)
      : target;
   // await this.waitForLoader(this.page)
    await sourceElement.waitFor({ state: 'visible', timeout: options?.timeout });
    await targetElement.waitFor({ state: 'visible', timeout: options?.timeout });

    await sourceElement.dragTo(targetElement, { force: options?.force });
  }

  // =================================
  // KEYBOARD AND MOUSE ACTIONS
  // =================================

  /**
   * Press a keyboard key
   */
  async pressKey(key) {
   // await this.waitForLoader(this.page)
    await this.page.keyboard.press(key);
  }

  /**
   * Press multiple keyboard keys simultaneously
   */
  async pressKeys(...keys) {
    //await this.waitForLoader(this.page)
    for (const key of keys.slice(0, -1)) {
      await this.page.keyboard.down(key);
    }

    const lastKey = keys[keys.length - 1];
    await this.page.keyboard.press(lastKey);

    for (const key of keys.slice(0, -1).reverse()) {
      await this.page.keyboard.up(key);
    }
  }

  /**
   * Type text without targeting a specific element
   */
  async keyboard(text, options) {
   // await this.waitForLoader(this.page);
    await this.page.keyboard.type(text, { delay: options?.delay || 50 });
  }

  /**
   * Scroll an element into view
   */
  async scrollIntoView(selector, options) {
    const element = typeof selector === 'string'
      ? this.page.locator(selector)
      : selector;
   // await this.waitForLoader(this.page)
    await element.waitFor({ state: 'attached', timeout: options?.timeout });
    await element.scrollIntoViewIfNeeded();
  }

  /**
   * Scroll to the top of the page
   */
  async scrollToTop() {
  //  await this.waitForLoader(this.page)
    await this.page.evaluate(() => window.scrollTo(0, 0));
  }

  /**
   * Scroll to the bottom of the page
   */
  async scrollToBottom() {
    //await this.waitForLoader(this.page)
    await this.page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
  }

  // =================================
  // WAITING UTILITIES
  // =================================

  /**
   * Wait for an element to be visible
   * options: { state: 'visible', timeout: 5000}
   */
  async waitForElement(selector, options) {
    const element = typeof selector === 'string'
      ? this.page.locator(selector)
      : selector;
    //await this.waitForLoader(this.page)
    await element.waitFor({
      state: options?.state || 'visible',
      timeout: options?.timeout || 10000
    });
  }

  /**
 * Wait for an element to be invisible
 */
  async waitForElementToBeInvisible(selector, options) {
    const element = typeof selector === 'string'
      ? this.page.locator(selector)
      : selector;
    //await this.waitForLoader(this.page)
    await element.waitFor({
      state: 'hidden', // Change state to 'hidden' for invisibility
      timeout: options?.timeout
    });
  }

  /**
* Wait for element to not be present in DOM.
*/
  async waitForElementToBeDetached(selector, options) {
    const element = typeof selector === 'string'
      ? this.page.locator(selector)
      : selector;
    //await this.waitForLoader(this.page)
    await element.waitFor({
      state: 'detached', // Change state to 'detached' for non existence of element in DOM
      timeout: options?.timeout
    });
  }

  /**
   * Wait for an element to contain specific text
   */
  async waitForElementText(selector, text, options) {
    const element = typeof selector === 'string'
      ? this.page.locator(selector)
      : selector;
    //await this.waitForLoader(this.page)
    await expect(element).toContainText(text, { timeout: options?.timeout });
  }

  /**
   * Wait for navigation to complete
   * option - load, domcontentloaded, networkidle
   */
  async waitForNavigation(options) {
   // await this.waitForLoader(this.page);
    await this.page.waitForLoadState(options?.waitUntil || 'networkidle', { timeout: options?.timeout });
  }


  /**
   * Wait for a URL change
   * @param {string | RegExp | function(URL): boolean} url - The URL to wait for.
   * @param {Object} [options] - Optional settings.
   * @param {number} [options.timeout] - Maximum time to wait for in milliseconds.
   * @param {"load" | "domcontentloaded" | "networkidle" | "commit"} [options.waitUntil] - When to consider navigation succeeded.
   */
  async waitForUrl(url, options = {}) {
   // await this.waitForLoader(this.page)
    await this.page.waitForURL(url, {
      timeout: options?.timeout,
      waitUntil: options?.waitUntil
    });
  }


  /**
   * Wait for a specific network request
   */
  async waitForRequest(urlOrPredicate, options) {
    return await this.page.waitForRequest(urlOrPredicate, { timeout: options?.timeout });
  }

  /**
   * Wait for a specific network response
   */
  async waitForResponse(urlOrPredicate, options) {
    return await this.page.waitForResponse(urlOrPredicate, { timeout: options?.timeout });
  }

  /**
   * Wait for a specific amount of time (note: use sparingly)
   */
  async wait(milliseconds) {
    await this.page.waitForTimeout(milliseconds);
  }

  // =================================
  // ELEMENT RETRIEVAL AND STATE
  // =================================

  /**
   * Get an element by selector
   */
  getElement(selector) {
    return this.page.locator(selector);
  }

  /**
   * Get multiple elements by selector
   */
  getElements(selector) {
    return this.page.locator(selector);
  }

  /**
   * Get element text content
   */
  async getElementText(selector) {
    const element = typeof selector === 'string'
      ? this.page.locator(selector)
      : selector;
    return await element.textContent();
  }

  /**
   * Get element attribute value
   */
  async getElementAttribute(selector, attributeName) {
    const element = typeof selector === 'string'
      ? this.page.locator(selector)
      : selector;
    return await element.getAttribute(attributeName);
  }

  /**
   * Get element count
   */
  async getElementCount(selector) {
    const element = typeof selector === 'string'
      ? this.page.locator(selector)
      : selector;
    return await element.count();
  }

  /**
   * Check if element is visible
   */
  async isElementVisible(selector, options) {
    const element = typeof selector === 'string'
      ? this.page.locator(selector)
      : selector;

    try {
      await element.waitFor({
        state: 'visible',
        timeout: options?.timeout || 5000
      });
      return true;
    } catch (error) {
      return false;
    }
  }

  /**
   * Check if element exists in DOM
   */
  async doesElementExist(selector, options) {
    const element = typeof selector === 'string'
      ? this.page.locator(selector)
      : selector;
    //await this.waitForLoader(this.page)
    try {
      await element.waitFor({
        state: 'attached',
        timeout: options?.timeout || 1000
      });
      return true;
    } catch (error) {
      return false;
    }
  }

  /**
   * Check if element is enabled
   */
  async isElementEnabled(selector) {
    const element = typeof selector === 'string'
      ? this.page.locator(selector)
      : selector;
   // await this.waitForLoader(this.page)
    return await element.isEnabled();
  }

  /**
   * Check if checkbox or radio is checked
   */
  async isElementChecked(selector) {
    const element = typeof selector === 'string'
      ? this.page.locator(selector)
      : selector;
   // await this.waitForLoader(this.page)
    return await element.isChecked();
  }

  // =================================
  // BROWSER CONTEXT OPERATIONS
  // =================================

  /**
   * Get current page URL
   */
  async getCurrentUrl() {
    const currentUrl = await this.page.url();
    return currentUrl;
  }

  /**
   * Get page title
   */
  async getPageTitle() {
    return await this.page.title();
  }

  /**
   * Take a screenshot
   */
  async takeScreenshot(options) {
    //await this.waitForLoader(this.page)
    return await this.page.screenshot(options);
  }

  /**
   * Take a screenshot of a specific element
   */
  async takeElementScreenshot(selector, options) {
    const element = typeof selector === 'string'
      ? this.page.locator(selector)
      : selector;
    //await this.waitForLoader(this.page)
    return await element.screenshot(options);
  }

  /**
   * Accept browser dialog (alert, confirm, prompt)
   */
  async acceptDialog(promptText) {
    //await this.waitForLoader(this.page)
    this.page.once('dialog', dialog => {
      if (promptText !== undefined && dialog.type() === 'prompt') {
        dialog.accept(promptText);
      } else {
        dialog.accept();
      }
    });
  }

  /**
   * Dismiss browser dialog (alert, confirm, prompt)
   */
  async dismissDialog() {
    //await this.waitForLoader(this.page)
    this.page.once('dialog', dialog => dialog.dismiss());
  }

  /**
   * Set viewport size
   */
  async setViewportSize(width, height) {
    //await this.waitForLoader(this.page)
    await this.page.setViewportSize({ width, height });
  }

  /**
   * Execute JavaScript in the browser context
   */
  async evaluate(pageFunction, ...args) {
    //await this.waitForLoader(this.page)
    return await this.page.evaluate(pageFunction, ...args);
  }

  /**
   * Add a script tag to the page
   */
  async addScriptTag(options) {
    await this.page.addScriptTag(options);
  }

  /**
   * Add a style tag to the page
   */
  async addStyleTag(options) {
    await this.page.addStyleTag(options);
  }

  // =================================
  // COOKIES AND STORAGE
  // =================================

  /**
   * Get browser cookies
   */
  async getCookies() {
    return await this.page.context().cookies();
  }

  /**
   * Set browser cookies
   */
  async setCookies(cookies) {
    await this.page.context().addCookies(cookies);
  }

  /**
   * Clear browser cookies
   */
  async clearCookies() {
    await this.page.context().clearCookies();
  }

  /**
   * Get localStorage item
   */
  async getLocalStorageItem(key) {
    return await this.page.evaluate((k) => window.localStorage.getItem(k), key);
  }

  /**
   * Set localStorage item
   */
  async setLocalStorageItem(key, value) {
    await this.page.evaluate(
      ([k, v]) => window.localStorage.setItem(k, v),
      [key, value]
    );
  }

  /**
   * Clear localStorage
   */
  async clearLocalStorage() {
    await this.page.evaluate(() => window.localStorage.clear());
  }

  /**
   * Get sessionStorage item
   */
  async getSessionStorageItem(key) {
    return await this.page.evaluate((k) => window.sessionStorage.getItem(k), key);
  }

  /**
   * Set sessionStorage item
   */
  async setSessionStorageItem(key, value) {
    await this.page.evaluate(
      ([k, v]) => window.sessionStorage.setItem(k, v),
      [key, value]
    );
  }

  /**
   * Clear sessionStorage
   */
  async clearSessionStorage() {
    await this.page.evaluate(() => window.sessionStorage.clear());
  }

  // =================================
  // NETWORK AND API INTERCEPT
  // =================================

  /**
   * Mock a network response
   */
  async mockNetworkResponse(url, status, body) {
    await this.page.route(url, route => {
      route.fulfill({
        status: status,
        contentType: 'application/json',
        body: JSON.stringify(body)
      });
    });
  }

  /**
   * Abort specific network requests
   */
  async abortRequests(url) {
    await this.page.route(url, route => route.abort());
  }

  /**
   * Disable browser cache
   */
  async disableCache() {
    await this.page.context().route('**/*', (route) => {
      const headers = route.request().headers();
      headers['Cache-Control'] = 'no-cache, no-store, must-revalidate';
      headers['Pragma'] = 'no-cache';
      headers['Expires'] = '0';
      route.continue({ headers });
    });
  }

  /**
   * Get all network requests
   */
  async trackRequests(urlPattern) {
    const requests = [];

    await this.page.route(urlPattern, route => {
      requests.push(route.request().url());
      route.continue();
    });

    return requests;
  }

  /**
   * Verifies that the page's URL contains the expected partial path.
   * @param expectedPartialUrl The expected URL or partial URL to check
   * @param pageInstance The Playwright Page instance to check URL from
   */
  async verifyUrlContainsPartialPath(expectedPartialUrl, pageInstance) {
    const currentUrl = pageInstance.url();

    try {
      // Parse URLs
      const currentUrlObj = new URL(currentUrl);
      const expectedUrlObj = new URL(expectedPartialUrl, currentUrlObj.origin);

      const actualPath = currentUrlObj.pathname;
      const expectedPath = expectedUrlObj.pathname;

      expect(actualPath).toContain(expectedPath);
    } catch (error) {
      throw new Error(`Error parsing URLs for verification: ${error}`);
    }
  }


  /**
  * Saves the PDF file with the specified options.
  *@author: Shruti Sarap
  **/
  async savePagePdf(options) {
    await this.page.pdf(options);
  }

  /**
   * Clicks an option and validates the page scrolls to the corresponding section.
   * @param {string} sectionSelector - Selector for the target section element.
   * @author: Manisha Padghane
   */

  async validateScrollToSection(sectionSelector) {
    const sectionBox = await sectionSelector.boundingBox();
    expect(sectionBox).not.toBeNull();

    const scrollY = await this.page.evaluate(() => window.scrollY);
    const viewportHeight = await this.page.evaluate(() => window.innerHeight);
    // Assert the section top is within the viewport
    await expect(sectionBox.y).toBeLessThan(scrollY + viewportHeight);
    await this.page.waitForTimeout(2000); // Optional wait to ensure section is visible
  }

  /**
   * @author : Manisha Padghane
   * Extracts the price from a price element based on the configured regex and currency.
   * @param {Locator} priceElement - The Playwright locator for the price element.
   * @returns {Promise<{value: number, currency: string, originalText: string}>} - The extracted price details.
   */
  async getPriceFromElement(priceElement) {
    const priceText = await this.getElementText(priceElement);
    const priceConfig = banner.priceFormat;

    // Assert configuration exists
    expect(priceConfig).toBeTruthy();
    expect(priceConfig.regex).toBeTruthy();
    expect(priceConfig.currency).toBeTruthy();

    // Create regex from config string
    const regex = new RegExp(priceConfig.regex);
    const matches = priceText.match(regex);
    expect(matches).toBeTruthy(); // Assert price matches pattern

    // Clean and parse price
    let priceValue = matches[1];
    if (priceConfig.replaceComma) {
      priceValue = priceValue.replace(',', '.');
    }
    priceValue = priceValue.replace(/\s/g, ''); // Remove spaces

    const numericPrice = parseFloat(priceValue);
    expect(numericPrice).toBeGreaterThan(0); // Assert price is positive

    return {
      value: numericPrice,
      currency: priceConfig.currency,
      originalText: priceText.trim()
    };
  }

  /*
   * @author: Manisha Padghane
   * Clicks a link and verifies navigation to the expected URL.
   * Handles both same-tab and new-tab links.
   * @param {Locator} linkLocator - The Playwright locator for the link to click.
   * @param {string} expectedUrl - The expected URL to verify after navigation.
   * @param {string} postNavigationAction - Action to take after navigation ('revert' or 'stay').
   * 'revert' will go back to the previous page, 'stay' will leave the new tab open.
   */
  async clickLinkAndVerifyNavigation(linkLocator, expectedUrl, postNavigationAction = 'revert') {
    const target = await linkLocator.getAttribute('target');
   // await this.waitForLoader(this.page);
    await this.waitForElement(linkLocator);
    await this.waitForLocatorVisible(this.page, linkLocator)
    // await this.page.waitForTimeout(10000); // Ensure the link is ready to be clicked
    if (target === '_blank') {
      // Link opens in a new tab
      const [newPage] = await Promise.all([
        this.page.waitForEvent('popup'),
        linkLocator.click(),
      ]);
      await newPage.waitForLoadState();
      await this.verifyUrlContainsPartialPath(expectedUrl, newPage);
      //await this.waitForLoader(newPage)
      //  await this.page.waitForTimeout(8000);

      if (postNavigationAction === 'revert') {
        await newPage.close();
      }
      // if 'stay', do nothing, leave the new tab open
    } else {
      // Link opens in the same tab
      await Promise.all([
        this.page.waitForNavigation(),
        linkLocator.click(),
      ]);
      await this.verifyUrlContainsPartialPath(expectedUrl, this.page);

      if (postNavigationAction === 'revert') {
        await this.page.waitForTimeout(2000); // optional wait before going back
        await this.page.goBack();
      }
      // if 'stay', do nothing, stay on the new page
    }
  }


  /**
   * Clicks a PDF link and verifies the download or navigation.
   * @author: Manisha Padghane
   * Handles both new tab and same tab PDF links.
   * @param {Locator} linkLocator - The Playwright locator for the PDF link.
   * @param {string} expectedUrl - The expected URL to verify after clicking the link.
   * @param {string} postNavigationAction - Action to take after clicking the link ('revert' or 'stay').
   * 'revert' will go back to the previous page, 'stay' will leave the new tab open.
   * Note: This method assumes the PDF link has a 'target' attribute that indicates whether it opens in a new tab.
    */
  // Simplified PDF handling method
  async clickPDFLinkAndVerify(linkLocator, expectedUrl, postNavigationAction = 'revert') {
    await this.waitForLoader(this.page)
    await this.waitForElement(linkLocator);
    await this.page.waitForTimeout(10000);

    const target = await linkLocator.getAttribute('target');

    if (target === '_blank') {
      // PDF in new tab
      try {
        const downloadPromise = this.page.waitForEvent('download', { timeout: 15000 });
        await linkLocator.click();
        const download = await downloadPromise;
        console.log(download.url() + 'downloaded PDF URL', expectedUrl);
        expect(download.url(), `Expected URL to contain: ${expectedUrl}`).toContain(expectedUrl);
      } catch (error) {
        throw new Error(`PDF download failed: ${error.message}`);
      }
    } else {
      // PDF in same tab
      try {
        await linkLocator.click();
        await this.page.waitForTimeout(3000); // Wait for PDF to load

        // Assert the current page URL contains the expected URL
        const currentUrl = this.page.url();
        expect(currentUrl, `Expected page URL to contain: ${expectedUrl}`).toContain(expectedUrl);

        if (postNavigationAction === 'revert') {
          await this.page.goBack();
          await this.page.waitForTimeout(2000);
        }
      } catch (error) {
        throw new Error(`PDF navigation failed: ${error.message}`);
      }
    }
  }

  /** * Retrieves the value of a code input field.
   * @param {string | Locator} selector - The selector or locator for the code input field.
   * @returns {Promise<string>} - The value of the code input field.
   **/
  async getCodeInputValue(selector) {
    const element = typeof selector === 'string'
      ? this.page.locator(selector)
      : selector;
    await element.waitFor({ state: 'visible', timeout: 10000 });
    return await element.inputValue();
  }

  async countVisibleElements(locator) {
    const count = await locator.count();
    let visibleCount = 0;

    for (let i = 0; i < count; i++) {
      const isVisible = await locator.nth(i).isVisible({ timeout: 1000 }).catch(() => false);
      if (isVisible) visibleCount++;
    }

    return visibleCount;
  }

  async waitForLocatorVisible(page, locator, timeoutMs = 60000) {
    const startTime = Date.now();
    const pollingInterval = 500;

    while (Date.now() - startTime < timeoutMs) {
      try {

        const isVisible = await locator.isVisible({ timeout: 1000 }).catch(() => false);

        if (isVisible) {
          await locator.scrollIntoViewIfNeeded();
          console.log('[waitForLocatorVisible] Element is visible and scrolled into view.');
          return;
        }
      } catch (err) {
        // silently ignore exceptions (locator may not be ready)
      }

      await page.waitForTimeout(pollingInterval);
    }

    throw new Error('[waitForLocatorVisible] Timeout: Element did not become visible within 60 seconds.');
  }

  async clickAtCenter(locator, options = {}) {
    await this.wait(10000) // Ensure the page is ready
    const boundingBox = await locator.boundingBox();
    if (!boundingBox) throw new Error('Element not visible or has no bounding box');
    const centerX = boundingBox.x + (boundingBox.width / 2);
    const centerY = boundingBox.y + (boundingBox.height / 2);
    await this.page.mouse.click(centerX, centerY);
    await this.page.waitForTimeout(options.waitAfterClick || 500);
  }

  // ---------- Helpers Loading ----------
  async _anyVisible(locator) {
    try {
      return await locator.evaluateAll(els =>
        els.some(el => {
          const style = window.getComputedStyle(el);
          const rect = el.getBoundingClientRect();
          return (
            style.display !== 'none' &&
            style.visibility !== 'hidden' &&
            style.visibility !== 'collapse' &&
            rect.width > 0 &&
            rect.height > 0 &&
            style.opacity !== '0'
          );
        })
      );
    } catch {
      return false;
    }
  }

  async _allGoneOrHidden(locator) {
    const count = await locator.count().catch(() => 0);
    if (count === 0) return true;
    return !(await this._anyVisible(locator));
  }

  async _waitForLoadersGeneric({
    makeLocator,
    tick,
    scrollDown200,
    scrollTop,
    selectors,
    maxTimeoutMs,
    pollingInterval
  }) {
    const startTime = Date.now();
    const maxRetry = 15;
    let didScroll = false;

    for (const selector of selectors) {
      try {
        const locator = makeLocator(selector);

        if (await this._allGoneOrHidden(locator)) {
         // console.log(`[loader] Absent/hidden at start: '${selector}'`);
          continue;
        }

        let retry = 0;
        while (retry < maxRetry) {
          if (Date.now() - startTime > maxTimeoutMs) {
            throw new Error(`[loader] Timeout: '${selector}' still visible after ${Math.floor(maxTimeoutMs / 1000)}s`);
          }

          if (await this._allGoneOrHidden(locator)) {
            console.log(`[loader] Gone/hidden: '${selector}'`);
            break;
          }

          console.log(`[loader] Still visible: '${selector}' (retry ${retry + 1}/${maxRetry})`);

          // Dès la 3ᵉ tentative → scroll à chaque tentative, tant que < 30 tentatives
          if (retry + 1 >= 3 && retry + 1 <= 30) {
            try {
              await scrollDown200();
              didScroll = true;
              console.log('[loader] Performed scrollDown(200px).');
            } catch (e) {
              console.warn('[loader] scrollDown failed:', e?.message || e);
            }
          }

          await Promise.race([
            locator.first().waitFor({ state: 'hidden', timeout: pollingInterval }).catch(() => { }),
            tick()
          ]);

          retry++;
        }

        if (retry >= maxRetry) {
          console.warn(`[loader] Max retries reached for '${selector}', moving on.`);
        }
      } catch {
        console.log(`[loader] Selector not found or already gone: '${selector}'`);
      }
    }

    if (didScroll) {
      try {
        await scrollTop();
        console.log('[loader] Performed final scrollTop().');
      } catch (e) {
        console.warn('[loader] scrollTop failed:', e?.message || e);
      }
    }
  }

  // ---------- Page ----------
  async waitForLoader(page, maxTimeoutMs = 180000) {
    console.log('[waitForLoader] Starting page readiness & loader wait…');

    await page.waitForLoadState('load', { timeout: 60000 }).catch(() =>
      console.warn('[waitForLoader] load not reached in 60s.')
    );
    await page.waitForLoadState('domcontentloaded', { timeout: 60000 }).catch(() =>
      console.warn('[waitForLoader] domcontentloaded not reached in 60s.')
    );

    const selectors = [
      '[data-testid*="loading"]',
      '[data-testid*="loader"]',
      '[data-testid*="skeleton-loader"]',
      '//*[contains(@class,"loader-inner")]',
      '//*[contains(@class,"skeleton-loader")]',
      '//*[contains(@class,"inner-section-loading")]',
      '//*[contains(@class,"loader")]',
      '//*[contains(@class,"loading")]',
      '//*[contains(@class,"fui-Spinner")]',
      '//*[contains(@class,"progress-bar")]',
      '//*[contains(@class,"spinnerTail")]'
    ];

    await this._waitForLoadersGeneric({
      makeLocator: sel => page.locator(sel),
      tick: () => page.waitForTimeout(1000),
      scrollDown200: () => page.evaluate(() => window.scrollBy(0, 200)),
      scrollTop: () => page.evaluate(() => window.scrollTo(0, 0)),
      selectors,
      maxTimeoutMs,
      pollingInterval: 1000
    });

    console.log('[waitForLoader] ✅ All page loaders are gone/hidden.');
  }

  // ---------- Iframe ----------
  async waitForLoaderIframe(frameLocator, maxTimeoutMs = 120000) {
    console.log('[waitForLoaderIframe] Waiting for iframe loaders to disappear…');

    const selectors = [
      '[data-testid*="loading"]',
      '[data-testid*="loader"]',
      '[data-testid*="skeleton-loader"]',
      '//*[contains(@class,"loader-inner")]',
      '//*[contains(@class,"skeleton-loader")]',
      '//*[contains(@class,"inner-section-loading")]',
      '//*[contains(@class,"loader")]',
      '//*[contains(@class,"loading")]',
      '//*[contains(@class,"progress-bar")]',
      '//*[contains(@class,"fui-Spinner")]',
      '//*[contains(@class,"spinnerTail")]'
    ];

    const page = this.page;

    await this._waitForLoadersGeneric({
      makeLocator: sel => frameLocator.locator(sel),
      tick: () => page.waitForTimeout(1000),
      scrollDown200: () =>
        frameLocator.locator('body').evaluate(el => el.ownerDocument.defaultView.scrollBy(0, 200)),
      scrollTop: () =>
        frameLocator.locator('body').evaluate(el => el.ownerDocument.defaultView.scrollTo(0, 0)),
      selectors,
      maxTimeoutMs,
      pollingInterval: 1000
    });

    console.log('[waitForLoaderIframe] ✅ All iframe loaders are gone/hidden.');
  }

}

module.exports = { webUtils: (page) => new WebUtils(page) };