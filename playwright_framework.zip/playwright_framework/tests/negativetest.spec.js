// negativetest.spec.js
const { test } = require('@playwright/test');
const { assertionUtils } = require('../utils/assertion-utils');
const { webUtils } = require('../utils/web-utils');

test.describe('Login Negative Test', () => {
  test('should show error for invalid username', async ({ page }) => {
    const web = webUtils(page);
    const assertUtils = assertionUtils(page);

    // Open login page
    await page.goto('https://practicetestautomation.com/practice-test-login/');

    // Fill form with invalid username
    await web.fillText('#username', 'incorrectUser');
    await web.fillText('#password', 'Password123');

    // Click Submit button
    await web.clickElement('#submit');

    // Verify error message is displayed
    await assertUtils.expectToBeVisible('#error');

    // Verify error message text
    await assertUtils.expectPageToContainText('Your username is invalid!');

    console.log('✅ Negative test passed: invalid username shows correct error message');
  });
});
