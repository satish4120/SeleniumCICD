// logintest.spec.js
const { test } = require('@playwright/test');
const { assertionUtils } = require('../utils/assertion-utils');
const { webUtils } = require('../utils/web-utils');

test.describe('Login Page UI Test', () => {
  test('should login successfully with valid credentials', async ({ page }) => {
    const web = webUtils(page);
    const assertUtils = assertionUtils(page);

    // Open login page
    await page.goto('https://practicetestautomation.com/practice-test-login/');

    // Fill in login form
    await web.fillText('#username', 'student');
    await web.fillText('#password', 'Password123');

    // Click Submit button
    await web.clickElement('#submit');

    // Verify new page URL
    await assertUtils.expectURLToContain('practicetestautomation.com/logged-in-successfully/');

    // Verify success messages
    await assertUtils.expectPageToContainText('Congratulations');
    await assertUtils.expectPageToContainText('successfully logged in');

    // Verify logout button
    await assertUtils.expectToBeVisible('text=Log out');

    console.log('✅ Login test passed: user logged in successfully and Log out button is visible');
  });
});
