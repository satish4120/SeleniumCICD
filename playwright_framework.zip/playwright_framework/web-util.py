from playwright.sync_api import Page, expect

class WebUtils:
    def __init__(self, page: Page):
        self.page = page

    def goto(self, url: str):
        self.page.goto(url)

    def click_element(self, selector: str):
        self.page.click(selector)

    def fill_input(self, selector: str, value: str):
        self.page.fill(selector, value)

    def get_text(self, selector: str) -> str:
        return self.page.inner_text(selector)

    def get_count(self, selector: str) -> int:
        return self.page.locator(selector).count()

    def is_visible(self, selector: str) -> bool:
        return self.page.is_visible(selector)

    def take_screenshot(self, path: str = "screenshot.png"):
        self.page.screenshot(path=path)

    def verify_redirection(self, expected_url: str):
        expect(self.page).to_have_url(expected_url)
